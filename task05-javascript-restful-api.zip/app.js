import {fetchProducts} from "./api.js";
const CACHE_KEY="task05_products_cache", PREF_KEY="task05_preferences";
const state={products:[],search:"",category:"all",sort:"default"};
const $=s=>document.querySelector(s);
const search=$("#search"),category=$("#category"),sort=$("#sort"),products=$("#products"),loading=$("#loading"),error=$("#errorBanner");

document.addEventListener("DOMContentLoaded",init);
async function init(){
 restorePreferences(); bindEvents(); renderSkeletons();
 try{
  const cached=readCache();
  if(cached){state.products=cached;hideLoading();populateCategories();renderProducts();}
  state.products=await fetchProducts(); saveCache(state.products);
  hideError();hideLoading();populateCategories();renderProducts();
 }catch(e){
  hideLoading();
  if(!state.products.length){showError("Unable to load products. Check your internet connection and try again.");products.innerHTML="<p>No product data is available right now.</p>";}
 }
}
function bindEvents(){
 search.addEventListener("input",e=>{state.search=e.target.value.toLowerCase().trim();savePreferences();renderProducts();});
 category.addEventListener("change",e=>{state.category=e.target.value;savePreferences();renderProducts();});
 sort.addEventListener("change",e=>{state.sort=e.target.value;savePreferences();renderProducts();});
}
function populateCategories(){
 const cats=[...new Set(state.products.map(p=>p.category))].sort();
 category.innerHTML='<option value="all">All categories</option>';
 cats.forEach(c=>{const o=document.createElement("option");o.value=c;o.textContent=c;category.appendChild(o);});
 category.value=state.category;
}
function visible(){
 let list=state.products.filter(p=>p.title.toLowerCase().includes(state.search)&&(state.category==="all"||p.category===state.category));
 list=[...list];
 if(state.sort==="price-low")list.sort((a,b)=>a.price-b.price);
 if(state.sort==="price-high")list.sort((a,b)=>b.price-a.price);
 if(state.sort==="name")list.sort((a,b)=>a.title.localeCompare(b.title));
 return list;
}
function renderProducts(){
 const list=visible();
 if(!list.length){products.innerHTML="<p>No products match your search or category.</p>";return;}
 products.innerHTML=list.map(p=>`<article class="product"><img src="${esc(p.image)}" alt="${esc(p.title)}"><div class="content"><div class="category">${esc(p.category)}</div><h2>${esc(p.title)}</h2><div class="price">$${Number(p.price).toFixed(2)}</div><button data-id="${p.id}">Save</button></div></article>`).join("");
 products.querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>saveProduct(Number(b.dataset.id))));
}
function saveProduct(id){
 const saved=JSON.parse(localStorage.getItem("task05_saved_products")||"[]");
 if(!saved.includes(id))saved.push(id); localStorage.setItem("task05_saved_products",JSON.stringify(saved));
 showError("Product preference saved locally.",false); setTimeout(hideError,1600);
}
function savePreferences(){localStorage.setItem(PREF_KEY,JSON.stringify(state));}
function restorePreferences(){try{const p=JSON.parse(localStorage.getItem(PREF_KEY)||"null");if(!p)return;state.search=p.search||"";state.category=p.category||"all";state.sort=p.sort||"default";search.value=state.search;sort.value=state.sort;}catch{}}
function saveCache(data){localStorage.setItem(CACHE_KEY,JSON.stringify({savedAt:Date.now(),products:data}));}
function readCache(){try{const c=JSON.parse(localStorage.getItem(CACHE_KEY)||"null");if(!c||!Array.isArray(c.products))return null;return Date.now()-c.savedAt<86400000?c.products:null;}catch{return null}}
function renderSkeletons(){products.innerHTML=Array.from({length:8},()=>'<div class="skeleton"></div>').join("");}
function hideLoading(){loading.hidden=true} function hideError(){error.hidden=true}
function showError(msg,isErr=true){error.textContent=msg;error.hidden=false;if(!isErr)setTimeout(hideError,1500);}
function esc(v){return String(v).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");}