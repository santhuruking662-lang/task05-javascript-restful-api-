# Task 05 – JavaScript ES6+ & RESTful API Client

This project demonstrates async/await fetch calls to the public Fake Store API, real-time search, category filtering, sorting without page reloads, localStorage caching/preferences, loading skeletons, friendly error handling, and modular JavaScript files.

Required proof is included through the modular `app.js` and `api.js` files.
